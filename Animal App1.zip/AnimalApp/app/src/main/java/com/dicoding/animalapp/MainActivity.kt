package com.dicoding.animalapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity(), View.OnClickListener, ListAnimalAdapter.OnItemClickListener {

    private lateinit var rvAnimal: RecyclerView
    private var list: ArrayList<Animal> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Toast.makeText(this, "Welcome", Toast.LENGTH_LONG).show()

        rvAnimal = findViewById(R.id.rv_animal)
        rvAnimal.setHasFixedSize(true)

        list.addAll(AnimalData.listData)
        showRecycleList()

        val tvMoveActivity: TextView = findViewById(R.id.tv_move_activity)
        tvMoveActivity.setOnClickListener(this)
    }

    private fun showRecycleList(){
        rvAnimal.layoutManager = LinearLayoutManager(this)
        val listAnimalAdapter = ListAnimalAdapter(list, this)
        rvAnimal.adapter = listAnimalAdapter

        listAnimalAdapter.setOnItemClickCallback(object : ListAnimalAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Animal) {
                showSelectedHero(data)
            }
        })
    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.tv_move_activity -> {
            }
        }
    }

    override fun onItemClick(position: Int) {
        Toast.makeText(this, "Item $position clicked", Toast.LENGTH_SHORT).show()
        val moveIntent = Intent(this@MainActivity, DetailAnimalActivity::class.java)
        moveIntent.putExtra("image", AnimalData.listData[position].img)
        moveIntent.putExtra("name" , AnimalData.listData[position].name)
        moveIntent.putExtra("detail", AnimalData.listData[position].detail)
        startActivity(moveIntent)
        val clickedItem = list[position]
        clickedItem.name = "clicked"
        clickedItem.detail = "clicked"
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            R.id.action_about -> {
                Toast.makeText(applicationContext, "About", Toast.LENGTH_SHORT).show()
                val aboutIntent = Intent(this@MainActivity, AboutActivity::class.java)
                startActivity(aboutIntent)
                true
            }

            R.id.action_favorite ->{
                true
            }

            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showSelectedHero(animal: Animal) {
        Toast.makeText(this, "Kamu memilih " + animal.name, Toast.LENGTH_SHORT).show()
    }
}

