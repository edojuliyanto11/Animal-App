package com.dicoding.animalapp

data class Animal(
    var name: String = "",
    var detail : String = "",
    var img : Int = 0,
)

