package com.dicoding.animalapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class DetailAnimalActivity : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.detail_animal_activity)

        val imgAnimal :ImageView = findViewById(R.id.img_animal_detail)
        val tvDetailAnimalName :TextView = findViewById(R.id.tvDetailAnimalName)
        val tvDetailAnimal :TextView = findViewById(R.id.tvDetailAnimal)

        val name = intent.getStringExtra("name")
        val detail = intent.getStringExtra("detail")
        val img = intent.getIntExtra("image", 1)
        tvDetailAnimalName.text = name
        tvDetailAnimal.text = detail
        imgAnimal.setImageResource(img)

        val actionbar = supportActionBar

        actionbar!!.title = "About"

        actionbar.setDisplayHomeAsUpEnabled(true)
        actionbar.setDisplayHomeAsUpEnabled(true)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}