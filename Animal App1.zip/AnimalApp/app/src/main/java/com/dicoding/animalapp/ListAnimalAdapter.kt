package com.dicoding.animalapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class ListAnimalAdapter(private val ListAnimal: ArrayList<Animal>, private val listener: OnItemClickListener): RecyclerView.Adapter<ListAnimalAdapter.ListViewHolder> () {

    private lateinit var onItemClickCallback: OnItemClickCallback

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    inner class ListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        var iName : TextView = itemView.findViewById(R.id.img_name)
        var iDetail : TextView = itemView.findViewById(R.id.img_detail)
        var iImg : ImageView = itemView.findViewById(R.id.img_animal)
        var iFav : Button = itemView.findViewById(R.id.btn_Fav)
        var iSha : Button = itemView.findViewById(R.id.btn_Sha)

        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View?) {
            val position:Int = adapterPosition
            if (position != RecyclerView.NO_POSITION) {
                listener.onItemClick(position)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val vw : View = LayoutInflater.from(parent.context).inflate(R.layout.item_animal, parent, false)
        return ListViewHolder(vw)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {

        val animal = ListAnimal[position]

        Glide.with(holder.itemView.context)
            .load(animal.img)
            .apply(RequestOptions().override(55, 55))
            .into(holder.iImg)

        holder.iName.text = animal.name
        holder.iDetail.text = animal.detail

        holder.iFav.setOnClickListener {
            Toast.makeText(
                holder.itemView.context,
                "Favorite " + ListAnimal[position].name,
                Toast.LENGTH_SHORT
            ).show()
        }

        holder.iSha.setOnClickListener {
            Toast.makeText(
                holder.itemView.context,
                "Share " + ListAnimal[position].name,
                Toast.LENGTH_SHORT
            ).show()
        }

        holder.itemView.setOnClickListener(){
            Toast.makeText(holder.itemView.context, "Kamu memilih " + ListAnimal[position].name, Toast.LENGTH_SHORT).show()
        }

        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(ListAnimal[holder.adapterPosition]) }
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: Animal)
    }

    override fun getItemCount(): Int {
        return ListAnimal.size
    }

    interface OnItemClickListener{
        fun onItemClick(position: Int)
    }
}